/**
 * 数据监控 监控查询
 */
<template>
  <div>数据监控 监控查询</div>
</template>

<script>
export default {

}
</script>

<style>

</style>

 